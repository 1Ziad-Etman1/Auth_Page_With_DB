<?php
    define('RAPIDAPI_KEY', 'cdf347b546mshf74412337e7be1dp1dbbe7jsn53d7dafdf85e');  
    define('RAPIDAPI_HOST', 'whatsapp-number-validator3.p.rapidapi.com');
    define('API_URL', 'https://whatsapp-number-validator3.p.rapidapi.com/WhatsappNumberHasItBulkWithToken');
?>