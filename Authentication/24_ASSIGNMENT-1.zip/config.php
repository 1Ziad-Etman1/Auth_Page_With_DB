<?php
    define('RAPIDAPI_KEY', '9b737a2573msh5bc3923a2b52103p1c60fejsndf2e96f2ceea');  
    define('RAPIDAPI_HOST', 'whatsapp-number-validator3.p.rapidapi.com');
    define('API_URL', 'https://whatsapp-number-validator3.p.rapidapi.com/WhatsappNumberHasItBulkWithToken');
?>