<footer class="footer">
    <div class="footer-container">
        <p class="footer-text">© 2025 TNT All rights reserved.</p>
        <div class="footer-links">
            <a href="#" class="footer-link">Privacy Policy</a>
            <a href="#" class="footer-link">Terms</a>
            <a href="#" class="footer-link">Contact</a>
        </div>
    </div>
</footer>