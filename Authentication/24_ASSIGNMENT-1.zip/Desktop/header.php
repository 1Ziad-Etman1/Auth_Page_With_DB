<header>
        <div class="hcontainer">
            <div class="header-bar">
                <h1 class="logo">TNT</h1>
                <ul class="slider-menu">
                    <li>Home</li>
                    <li>About</li>
                    <li>Services</li>
                </ul>
            </div>
        </div>
</header>